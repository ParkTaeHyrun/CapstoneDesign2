package com.earthquake.analysis.controller;

import com.earthquake.analysis.entity.Earthquake;
import com.earthquake.analysis.service.EarthquakeService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/earthquakes")
@CrossOrigin
public class EarthquakeController {

    private final EarthquakeService service;

    public EarthquakeController(EarthquakeService service) {
        this.service = service;
    }

    @GetMapping
    public List<Earthquake> getAll() {
        return service.getAllEarthquakes();
    }
}
