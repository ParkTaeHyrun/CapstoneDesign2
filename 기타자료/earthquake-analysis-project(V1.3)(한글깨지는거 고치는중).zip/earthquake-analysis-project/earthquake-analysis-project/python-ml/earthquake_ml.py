import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import joblib
import mysql.connector

conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='20197604',
    database='earthquake_db'
)

query = "SELECT * FROM earthquake"
df = pd.read_sql(query, conn)

X = df[['latitude', 'longitude', 'magnitude']]
y = (df['magnitude'] >= 4.0).astype(int)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
model = RandomForestClassifier()
model.fit(X_train, y_train)

joblib.dump(model, 'earthquake_model.pkl')

cursor = conn.cursor()
cursor.execute("DROP TABLE IF EXISTS risk_analysis")
cursor.execute("""
    CREATE TABLE risk_analysis (
        id INT AUTO_INCREMENT PRIMARY KEY,
        location VARCHAR(255),
        probability DOUBLE,
        status VARCHAR(50),
        seismic_design BOOLEAN
    )
""")
for _, row in df.iterrows():
    features = np.array([[row['latitude'], row['longitude'], row['magnitude']]])
    prob = model.predict_proba(features)[0][1]
    status = (
        "아주위험합니다" if prob > 0.8 else
        "위험합니다" if prob > 0.6 else
        "보통입니다" if prob > 0.4 else
        "안전합니다"
    )
    seismic = np.random.choice([True, False])
    cursor.execute("INSERT INTO risk_analysis (location, probability, status, seismic_design) VALUES (%s, %s, %s, %s)",
                   (row['location'], prob, status, seismic))

conn.commit()
cursor.close()
conn.close()
