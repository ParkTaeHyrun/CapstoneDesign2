async function fetchEarthquakeData() {
  const res = await fetch("http://localhost:8080/api/earthquakes");
  return await res.json();
}

function initMap() {
  const map = new google.maps.Map(document.getElementById("map"), {
    center: { lat: 36.5, lng: 127.5 },
    zoom: 7
  });

  fetchEarthquakeData().then(data => {
    data.forEach(eq => {
      const marker = new google.maps.Marker({
        position: { lat: eq.latitude, lng: eq.longitude },
        map: map,
        title: eq.location
      });

      marker.addListener("click", () => {
        const prob = Math.random();
        const msg = prob > 0.8 ? "아주위험합니다" :
                    prob > 0.6 ? "위험합니다" :
                    prob > 0.4 ? "보통입니다" :
                    "안전합니다";
        const seismic = Math.random() > 0.5 ? "있음" : "없음";

        document.getElementById("info").innerHTML =
          `<strong>${eq.location}</strong><br>지진 발생 확률: ${(prob*100).toFixed(1)}%<br>위험도: ${msg}<br>내진설계: ${seismic}`;
      });
    });
  });
}

window.onload = initMap;