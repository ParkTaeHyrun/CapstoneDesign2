package com.earthquake.analysis.service;

import com.earthquake.analysis.entity.Earthquake;
import com.earthquake.analysis.repository.EarthquakeRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Service
public class EarthquakeService {

    private final EarthquakeRepository repository;

    public EarthquakeService(EarthquakeRepository repository) {
        this.repository = repository;
    }
    
    public List<Earthquake> getAllEarthquakes() {
        return repository.findAll();
    }
    
    @PostConstruct
    public void fetchAndSaveEarthquakeData() {
        String urlStr = "https://apihub.kma.go.kr/api/typ01/url/eqk_list.php?tm1=200111231215&tm2=202411231215&disp=0&help=0&authKey=IgNe-epfS8mDXvnqXwvJiQ";

        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(
            	    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));


            String line;
            int lineNum = 0;
            while ((line = reader.readLine()) != null) {
                lineNum++;
                if (line.startsWith("#") || line.trim().isEmpty()) {
                    continue; // 주석 또는 빈 줄 제외
                }

                String[] parts = line.trim().split("\\s+"); // 공백 기준 분리

                try {
                    if (parts.length < 9) {
                        System.out.println("⚠️ 스킵 (줄 " + lineNum + ") 열 부족: " + line);
                        continue;
                    }

                    Earthquake eq = new Earthquake();
                    eq.setTime(parts[1]);
                    eq.setMagnitude(Double.parseDouble(parts[4]));
                    eq.setLatitude(Double.parseDouble(parts[5]));
                    eq.setLongitude(Double.parseDouble(parts[6]));
                    eq.setLocation(parts[7]);

                    repository.save(eq);

                } catch (Exception e) {
                    System.out.println("❌ 변환 오류 (줄 " + lineNum + "): " + e.getMessage());
                }
            }

            reader.close();
            System.out.println("✅ 지진 데이터 저장 완료!");

        } catch (IOException e) {
            System.out.println("❌ 연결 오류: " + e.getMessage());
        }
    }
}
