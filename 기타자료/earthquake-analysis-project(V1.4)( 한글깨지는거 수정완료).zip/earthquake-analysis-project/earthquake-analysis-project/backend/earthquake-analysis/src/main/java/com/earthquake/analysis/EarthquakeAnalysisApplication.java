package com.earthquake.analysis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EarthquakeAnalysisApplication {
    public static void main(String[] args) {
        SpringApplication.run(EarthquakeAnalysisApplication.class, args);
    }
}