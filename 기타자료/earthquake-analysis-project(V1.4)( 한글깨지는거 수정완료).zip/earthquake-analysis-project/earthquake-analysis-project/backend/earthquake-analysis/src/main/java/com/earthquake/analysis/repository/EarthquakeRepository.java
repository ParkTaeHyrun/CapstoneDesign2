package com.earthquake.analysis.repository;

import com.earthquake.analysis.entity.Earthquake;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EarthquakeRepository extends JpaRepository<Earthquake, Long> {
}
